/* =========================================================
   HOTPST · app.js  (v2)
   Todo se guarda en el navegador (localStorage).
   Nota: las cuentas son locales (demo). Para cuentas reales
   que funcionen entre dispositivos se necesita un servidor.
   ========================================================= */

/* ---------- CONFIGURACIÓN (edítala a tu gusto) ---------- */
const CONFIG = {
  ADMIN_PIN: "1234",             // PIN para entrar a Admin (cámbialo)
  VIDEO_SRC: "assets/video.mp4", // ruta de tu video
  VIDEO_START: 0,                // segundo donde empieza el recorte
  VIDEO_END: 0,                  // segundo donde termina (0 = hasta el final)
  CURRENCY: "MXN",
  ROTATOR: ["perfumes originales", "decants para probar", "tu próxima firma olfativa", "el regalo ideal"]
};

/* ---------- Utilidades ---------- */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const money = n => new Intl.NumberFormat("es-MX", { style: "currency", currency: CONFIG.CURRENCY, maximumFractionDigits: 2 }).format(n);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const load = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v ?? d; } catch { return d; } };
const save = (k, v) => {
  try { localStorage.setItem(k, JSON.stringify(v)); return true; }
  catch { toast("No hay espacio para guardar. Usa imágenes más pequeñas."); return false; }
};
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const finalPrice = p => +(p.precio * (1 - (p.descuento || 0) / 100)).toFixed(2);

function toast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => t.classList.remove("show"), 2600);
}

/* ---------- Estado ---------- */
const SAMPLE = [
  { id: uid(), tipo: "perfume", nombre: "Perfume de ejemplo", marca: "Marca", ml: 100, precio: 1800, descuento: 15, descripcion: "Notas cítricas y amaderadas. Bórralo o edítalo desde Admin.", imagen: "" },
  { id: uid(), tipo: "decant", nombre: "Decant de ejemplo", marca: "Marca", ml: 5, precio: 180, descuento: 0, descripcion: "Prueba la fragancia antes de comprar el frasco.", imagen: "" }
];
let products = load("hotpst_products", null);
if (!products) { products = SAMPLE; save("hotpst_products", products); }
let cart = load("hotpst_cart", []);          // [{id, qty}]
let orders = load("hotpst_orders", []);
let users = load("hotpst_users", []);
let sessionId = load("hotpst_session", null);
let favs = load("hotpst_favs", []);
const AD_DEFAULT = {
  on: true,
  tag: "Ya en Hotpst",
  title: "Lattafa",
  text: "Fragancias árabes de carácter intenso. Pruébalas primero en decant o llévate el frasco completo.",
  query: "lattafa"
};
let settings = load("hotpst_settings", { whatsapp: "" });
settings.ad = { ...AD_DEFAULT, ...(settings.ad || {}) };
let filter = "todos", query = "", sortBy = "recientes";

const currentUser = () => users.find(u => u.id === sessionId) || null;
const bottleSVG = '<svg viewBox="0 0 100 140"><use href="#bottle"/></svg>';
const decantSVG = '<svg viewBox="0 0 60 140"><use href="#decant"/></svg>';
const placeholder = p => p.tipo === "decant" ? decantSVG : bottleSVG;

/* =========================================================
   VIDEO (con recorte opcional)
   ========================================================= */
(function initVideo() {
  const v = $("#heroVideo");
  v.src = CONFIG.VIDEO_SRC;
  v.addEventListener("loadedmetadata", () => { if (CONFIG.VIDEO_START) v.currentTime = CONFIG.VIDEO_START; });
  v.addEventListener("canplay", () => { v.classList.add("ready"); v.play().catch(() => {}); });
  v.addEventListener("timeupdate", () => {
    if (CONFIG.VIDEO_END && v.currentTime >= CONFIG.VIDEO_END) v.currentTime = CONFIG.VIDEO_START || 0;
  });
  v.addEventListener("error", () => v.remove());
})();

/* =========================================================
   PANELES (abrir / cerrar)
   ========================================================= */
function openEl(id) { const el = $("#" + id); el.classList.add("open"); el.setAttribute("aria-hidden", "false"); }
function closeEl(id) { const el = $("#" + id); el.classList.remove("open"); el.setAttribute("aria-hidden", "true"); }
$("#btnCart").onclick = () => openEl("drawer");
$$(".modal").forEach(m => m.addEventListener("click", e => { if (e.target === m) closeEl(m.id); }));
document.addEventListener("keydown", e => { if (e.key === "Escape") ["drawer", "modalOrder", "modalAdmin", "modalDetail", "modalAccount"].forEach(closeEl); });

/* =========================================================
   BIENVENIDA + CUENTAS
   ========================================================= */
const welcome = $("#welcome");

function showWelcome() {
  document.body.classList.add("locked");
  welcome.classList.remove("gone");
  void welcome.offsetWidth;
  welcome.classList.remove("out");
  showHome();
}
function enterSite() {
  sessionStorage.setItem("hotpst_entered", "1");
  welcome.classList.add("out");
  document.body.classList.remove("locked");
  setTimeout(() => welcome.classList.add("gone"), 1000);
  updateAccountUI();
}
function showHome() { $("#wHome").hidden = false; $("#wAuth").hidden = true; }
function showAuth(mode) {
  $("#wHome").hidden = true; $("#wAuth").hidden = false;
  setMode(mode);
}
function setMode(mode) {
  $$(".auth-tab").forEach(t => t.classList.toggle("active", t.dataset.mode === mode));
  $("#authPill").classList.toggle("r", mode === "register");
  $("#loginForm").hidden = mode !== "login";
  $("#registerForm").hidden = mode !== "register";
  $("#loginErr").hidden = $("#registerErr").hidden = true;
}
$("#btnLogin").onclick = () => showAuth("login");
$("#btnRegister").onclick = () => showAuth("register");
$("#btnGuest").onclick = enterSite;
$("#btnGuest2").onclick = enterSite;
$("#btnBack").onclick = showHome;
$$(".auth-tab").forEach(t => t.onclick = () => setMode(t.dataset.mode));

async function hashPw(pw, salt) {
  try {
    if (window.crypto?.subtle) {
      const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(salt + pw));
      return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, "0")).join("");
    }
  } catch { /* usa el respaldo */ }
  let h = 5381; const s = salt + pw;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return "f" + (h >>> 0).toString(16);
}
function showErr(id, msg) { const el = $("#" + id); el.textContent = msg; el.hidden = false; }

$("#registerForm").addEventListener("submit", async e => {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  const correo = f.correo.trim().toLowerCase();
  if (users.some(u => u.correo === correo)) return showErr("registerErr", "Ese correo ya tiene una cuenta. Inicia sesión.");
  const salt = uid();
  const user = { id: uid(), nombre: f.nombre.trim(), correo, telefono: f.telefono.trim(), direccion: (f.direccion || "").trim(), salt, hash: await hashPw(f.password, salt) };
  users.push(user);
  if (!save("hotpst_users", users)) { users.pop(); return; }
  sessionId = user.id; save("hotpst_session", sessionId);
  e.target.reset();
  toast(`¡Bienvenido, ${user.nombre.split(" ")[0]}!`);
  enterSite();
});

$("#loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  const user = users.find(u => u.correo === f.correo.trim().toLowerCase());
  if (!user || user.hash !== await hashPw(f.password, user.salt)) return showErr("loginErr", "Correo o contraseña incorrectos.");
  sessionId = user.id; save("hotpst_session", sessionId);
  e.target.reset();
  toast(`Hola de nuevo, ${user.nombre.split(" ")[0]}`);
  enterSite();
});

function updateAccountUI() {
  const u = currentUser();
  $("#acctLabel").textContent = u ? u.nombre.split(" ")[0] : "Entrar";
}
$("#btnAccount").onclick = () => {
  if (!currentUser()) return showWelcome();
  renderAccount();
  openEl("modalAccount");
};
$("#btnGuestLogin").onclick = () => { closeEl("modalOrder"); showWelcome(); showAuth("login"); };

/* --- Mi cuenta --- */
function renderAccount() {
  const u = currentUser(); if (!u) return;
  $("#acctTitle").textContent = `Hola, ${u.nombre.split(" ")[0]}`;
  const f = $("#profileForm");
  f.nombre.value = u.nombre; f.telefono.value = u.telefono; f.correo.value = u.correo; f.direccion.value = u.direccion || "";
  const mine = orders.filter(o => o.userId === u.id || o.comprador.correo?.toLowerCase() === u.correo);
  $("#myOrders").innerHTML = mine.length ? mine.map(orderCard).join("") : '<p class="empty-cart">Aún no tienes pedidos.</p>';
}
function orderCard(o, admin = false) {
  return `<div class="order-card">
    <h4>${esc(o.comprador.nombre)}</h4>
    <small>${new Date(o.fecha).toLocaleString("es-MX")}</small>
    <ul>${o.items.map(i => `<li>${i.qty} × ${esc(i.nombre)} — ${money(i.precio * i.qty)}</li>`).join("")}</ul>
    <div><b>Total: ${money(o.total)}</b></div>
    ${admin ? `<div>📞 ${esc(o.comprador.telefono)} · ✉️ ${esc(o.comprador.correo)}</div>
    <div>📍 ${esc(o.comprador.direccion)}</div>` : ""}
    ${o.notas ? `<div>📝 ${esc(o.notas)}</div>` : ""}
    ${admin ? `<button class="rm" data-delo="${o.id}">Eliminar compra</button>` : ""}
  </div>`;
}
$$("#acctTabs .tab").forEach(tab => tab.onclick = () => {
  $$("#acctTabs .tab").forEach(t => t.classList.toggle("active", t === tab));
  ["aProfile", "aOrders"].forEach(id => $("#" + id).classList.toggle("active", id === tab.dataset.atab));
});
$("#profileForm").addEventListener("submit", e => {
  e.preventDefault();
  const u = currentUser(); if (!u) return;
  const f = e.target;
  u.nombre = f.nombre.value.trim(); u.telefono = f.telefono.value.trim(); u.direccion = f.direccion.value.trim();
  save("hotpst_users", users); updateAccountUI(); renderAccount(); toast("Datos guardados");
});
$("#btnLogout").onclick = () => {
  sessionId = null; save("hotpst_session", null);
  closeEl("modalAccount"); updateAccountUI(); toast("Sesión cerrada");
};

/* =========================================================
   CATÁLOGO
   ========================================================= */
function visibleProducts() {
  const q = query.trim().toLowerCase();
  let list = products.filter(p => {
    if (filter === "favs" && !favs.includes(p.id)) return false;
    if ((filter === "perfume" || filter === "decant") && p.tipo !== filter) return false;
    return !q || [p.nombre, p.marca, p.descripcion].join(" ").toLowerCase().includes(q);
  });
  const sorters = {
    "precio-asc": (a, b) => finalPrice(a) - finalPrice(b),
    "precio-desc": (a, b) => finalPrice(b) - finalPrice(a),
    "descuento": (a, b) => (b.descuento || 0) - (a.descuento || 0),
    "nombre": (a, b) => a.nombre.localeCompare(b.nombre, "es")
  };
  if (sorters[sortBy]) list = [...list].sort(sorters[sortBy]);
  return list;
}

function renderGrid() {
  const list = visibleProducts();
  const empty = $("#empty");
  empty.hidden = list.length > 0;
  if (!list.length) {
    empty.innerHTML = filter === "favs" ? "Aún no tienes favoritos. Toca el corazón de un perfume para guardarlo."
      : query ? "No encontramos resultados para tu búsqueda."
      : "Aún no hay productos. Entra a <b>Admin</b> para agregar el primero.";
  }
  $("#grid").innerHTML = list.map((p, i) => `
    <article class="card" style="--i:${Math.min(i, 12)}" data-id="${p.id}">
      <span class="tag ${p.tipo}">${p.tipo === "decant" ? "Decant" : "Perfume"}</span>
      ${p.descuento > 0 ? `<span class="off">-${p.descuento}%</span>` : ""}
      <button class="fav ${favs.includes(p.id) ? "on" : ""}" data-fav="${p.id}" aria-label="Favorito"><svg><use href="#heart"/></svg></button>
      <div class="card-img" data-view="${p.id}">
        ${p.imagen ? `<img src="${p.imagen}" alt="${esc(p.nombre)}" loading="lazy" decoding="async">` : placeholder(p)}
        <span class="view">Ver detalle</span>
      </div>
      <div class="card-body">
        <div class="brandline">${esc(p.marca)}</div>
        <h3 data-view="${p.id}">${esc(p.nombre)}</h3>
        <p class="desc">${esc(p.descripcion)}</p>
        <div class="meta">
          <div class="price">
            ${p.descuento > 0 ? `<s>${money(p.precio)}</s>` : ""}
            <b>${money(finalPrice(p))}</b>
            ${p.ml ? `<span class="ml">${p.ml} ml</span>` : ""}
          </div>
          <button class="btn sm" data-add="${p.id}">Agregar</button>
        </div>
      </div>
    </article>`).join("");
  $("#favCount").textContent = favs.filter(id => products.some(p => p.id === id)).length;
  updateStats();
  requestAnimationFrame(() => movePill());
}

/* Filtros con indicador animado */
function movePill(instant) {
  const active = $(".chip.active"), pill = $("#pill");
  if (!active || !active.offsetWidth) return;
  if (instant === true) pill.style.transition = "none";
  pill.style.width = active.offsetWidth + "px";
  pill.style.transform = `translateX(${active.offsetLeft}px)`;
  if (instant === true) { void pill.offsetWidth; pill.style.transition = ""; }
}
$("#filters").addEventListener("click", e => {
  const chip = e.target.closest(".chip");
  if (!chip) return;
  $$(".chip").forEach(c => c.classList.toggle("active", c === chip));
  filter = chip.dataset.filter;
  movePill(); renderGrid();
});
window.addEventListener("resize", () => movePill(true));
if (window.ResizeObserver) new ResizeObserver(() => movePill(true)).observe($("#filters"));
window.addEventListener("load", () => movePill(true));
let searchT;
$("#search").addEventListener("input", e => { clearTimeout(searchT); searchT = setTimeout(() => { query = e.target.value; renderGrid(); }, 180); });
$("#sort").addEventListener("change", e => { sortBy = e.target.value; renderGrid(); });

/* Favoritos */
function toggleFav(id) {
  favs = favs.includes(id) ? favs.filter(f => f !== id) : [...favs, id];
  save("hotpst_favs", favs);
  const on = favs.includes(id);
  $$(`[data-fav="${id}"]`).forEach(b => {
    b.classList.toggle("on", on);
    b.classList.remove("pop"); void b.offsetWidth; b.classList.add("pop");
  });
  $("#favCount").textContent = favs.filter(f => products.some(p => p.id === f)).length;
  toast(on ? "Guardado en favoritos" : "Quitado de favoritos");
  if (filter === "favs") renderGrid();
}

/* Detalle de producto */
function openDetail(id) {
  const p = products.find(x => x.id === id); if (!p) return;
  $("#detailBody").innerHTML = `
    <div class="detail">
      <div class="d-img">
        <span class="tag ${p.tipo}">${p.tipo === "decant" ? "Decant" : "Perfume"}</span>
        ${p.imagen ? `<img src="${p.imagen}" alt="${esc(p.nombre)}">` : placeholder(p)}
      </div>
      <div>
        <div class="brandline">${esc(p.marca)}</div>
        <h3>${esc(p.nombre)}</h3>
        <p class="desc">${esc(p.descripcion) || "Sin descripción."}</p>
        <div class="price">
          ${p.descuento > 0 ? `<s>${money(p.precio)} · ahorras ${p.descuento}%</s>` : ""}
          <b>${money(finalPrice(p))}</b>
          ${p.ml ? `<span class="ml">${p.ml} ml</span>` : ""}
        </div>
        <div class="row">
          <button class="btn" data-add="${p.id}">Agregar al carrito</button>
          <button class="btn ghost" data-fav="${p.id}">${favs.includes(p.id) ? "♥ En favoritos" : "♡ Favorito"}</button>
        </div>
      </div>
    </div>`;
  openEl("modalDetail");
}

/* =========================================================
   CARRITO
   ========================================================= */
const cartItems = () => cart.map(c => ({ ...c, p: products.find(p => p.id === c.id) })).filter(x => x.p);
const cartTotal = () => cartItems().reduce((s, x) => s + finalPrice(x.p) * x.qty, 0);

function renderCart() {
  const items = cartItems();
  $("#cartCount").textContent = items.reduce((s, x) => s + x.qty, 0);
  $("#cartTotal").textContent = money(cartTotal());
  $("#cartList").innerHTML = items.length ? items.map(({ p, qty }) => `
    <div class="ci">
      <div class="ci-img">${p.imagen ? `<img src="${p.imagen}" alt="">` : placeholder(p)}</div>
      <div>
        <h4>${esc(p.nombre)}</h4>
        <small>${p.tipo === "decant" ? "Decant" : "Perfume"}${p.ml ? " · " + p.ml + " ml" : ""} · ${money(finalPrice(p))}</small>
        <div class="qty"><button data-dec="${p.id}">−</button><span>${qty}</span><button data-inc="${p.id}">+</button></div>
      </div>
      <button class="rm" data-rm="${p.id}">Quitar</button>
    </div>`).join("") : '<p class="empty-cart">Tu carrito está vacío.</p>';
  save("hotpst_cart", cart);
}
function addToCart(id) {
  const it = cart.find(c => c.id === id);
  it ? it.qty++ : cart.push({ id, qty: 1 });
  renderCart();
  const b = $("#cartCount"); b.classList.remove("bump"); void b.offsetWidth; b.classList.add("bump");
  toast("Agregado al carrito");
}

/* Delegación de clics */
document.addEventListener("click", e => {
  const el = e.target.closest("[data-add],[data-inc],[data-dec],[data-rm],[data-close],[data-fav],[data-view],[data-delp],[data-delo],[data-edit]");
  if (!el) return;
  const d = el.dataset;
  if (d.add) addToCart(d.add);
  else if (d.inc) { cart.find(c => c.id === d.inc).qty++; renderCart(); }
  else if (d.dec) { const it = cart.find(c => c.id === d.dec); it.qty--; if (it.qty <= 0) cart = cart.filter(c => c !== it); renderCart(); }
  else if (d.rm) { cart = cart.filter(c => c.id !== d.rm); renderCart(); }
  else if (d.close) closeEl(d.close);
  else if (d.fav) { toggleFav(d.fav); if (el.classList.contains("btn")) el.textContent = favs.includes(d.fav) ? "♥ En favoritos" : "♡ Favorito"; }
  else if (d.view) openDetail(d.view);
  else if (d.delp) deleteProduct(d.delp);
  else if (d.delo) deleteOrder(d.delo);
  else if (d.edit) startEdit(d.edit);
});

/* =========================================================
   REGISTRO DE COMPRA
   ========================================================= */
$("#btnCheckout").onclick = () => {
  if (!cartItems().length) return toast("Agrega al menos un perfume");
  closeEl("drawer");
  const u = currentUser(), f = $("#orderForm");
  $("#guestNote").hidden = !!u;
  if (u) { f.nombre.value ||= u.nombre; f.telefono.value ||= u.telefono; f.correo.value ||= u.correo; f.direccion.value ||= u.direccion || ""; }
  renderOrderSummary();
  openEl("modalOrder");
};
$("#btnMore").onclick = () => { closeEl("modalOrder"); location.hash = "#catalogo"; toast("Agrega otro perfume al carrito"); };

function renderOrderSummary() {
  $("#orderSummary").innerHTML = cartItems().map(({ p, qty }) =>
    `<div><span>${qty} × ${esc(p.nombre)}${p.tipo === "decant" ? " (decant)" : ""}</span><span>${money(finalPrice(p) * qty)}</span></div>`).join("")
    + `<div class="t"><span>Total</span><span>${money(cartTotal())}</span></div>`;
}

$("#orderForm").addEventListener("submit", e => {
  e.preventDefault();
  const items = cartItems();
  if (!items.length) return toast("Tu carrito está vacío");
  const f = Object.fromEntries(new FormData(e.target));
  const order = {
    id: uid(), fecha: new Date().toISOString(), userId: sessionId || null,
    comprador: { nombre: f.nombre.trim(), telefono: f.telefono.trim(), correo: f.correo.trim(), direccion: f.direccion.trim() },
    notas: (f.notas || "").trim(),
    items: items.map(({ p, qty }) => ({ nombre: p.nombre, tipo: p.tipo, ml: p.ml, qty, precio: finalPrice(p) })),
    total: +cartTotal().toFixed(2)
  };
  orders.unshift(order);
  if (!save("hotpst_orders", orders)) { orders.shift(); return; }

  if (settings.whatsapp) {
    const txt = encodeURIComponent(`Hola Hotpst, soy ${order.comprador.nombre}.\n` +
      order.items.map(i => `• ${i.qty} × ${i.nombre}`).join("\n") +
      `\nTotal: ${money(order.total)}\nDirección: ${order.comprador.direccion}`);
    window.open(`https://wa.me/${settings.whatsapp}?text=${txt}`, "_blank");
  }
  cart = []; renderCart(); e.target.reset(); closeEl("modalOrder");
  toast("¡Compra registrada! Gracias ✨");
  renderAdmin();
});

/* =========================================================
   ADMIN
   ========================================================= */
let unlocked = false, editingId = null, pendingImage = "";

$("#btnAdmin").onclick = () => {
  if (!unlocked) {
    const pin = prompt("PIN de administrador:");
    if (pin === null) return;
    if (pin !== CONFIG.ADMIN_PIN) return toast("PIN incorrecto");
    unlocked = true;
  }
  renderAdmin();
  openEl("modalAdmin");
  $("#menu").classList.remove("open"); $("#burger").classList.remove("open");
};

function switchTab(id) {
  $$("#adminTabs .tab").forEach(t => t.classList.toggle("active", t.dataset.tab === id));
  $$("#modalAdmin .tabpane").forEach(p => p.classList.toggle("active", p.id === id));
}
$$("#adminTabs .tab").forEach(tab => tab.onclick = () => switchTab(tab.dataset.tab));

/* Imagen: se reduce y se guarda en el navegador */
$("#productForm").elements.imagen.addEventListener("change", e => {
  const file = e.target.files[0], prev = $("#imgPreview");
  if (!file) { pendingImage = ""; if (!editingId) prev.hidden = true; return; }
  const img = new Image(), url = URL.createObjectURL(file);
  img.onload = () => {
    const k = Math.min(1, 640 / Math.max(img.width, img.height));
    const c = document.createElement("canvas");
    c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    pendingImage = c.toDataURL("image/jpeg", .8);
    prev.src = pendingImage; prev.hidden = false;
    URL.revokeObjectURL(url);
  };
  img.src = url;
});

function resetProductForm() {
  const f = $("#productForm");
  f.reset(); pendingImage = ""; editingId = null;
  $("#imgPreview").hidden = true;
  $("#btnSaveProduct").textContent = "Guardar producto";
  $("#btnCancelEdit").hidden = true;
  $("#tabAddBtn").textContent = "Agregar producto";
}
function startEdit(id) {
  const p = products.find(x => x.id === id); if (!p) return;
  const f = $("#productForm");
  editingId = id; pendingImage = "";
  f.nombre.value = p.nombre; f.marca.value = p.marca || ""; f.tipo.value = p.tipo;
  f.ml.value = p.ml || ""; f.precio.value = p.precio; f.descuento.value = p.descuento || 0; f.descripcion.value = p.descripcion || "";
  f.imagen.value = "";
  const prev = $("#imgPreview"); if (p.imagen) { prev.src = p.imagen; prev.hidden = false; } else prev.hidden = true;
  $("#btnSaveProduct").textContent = "Guardar cambios";
  $("#btnCancelEdit").hidden = false;
  $("#tabAddBtn").textContent = "Editar producto";
  switchTab("tabAdd");
}
$("#btnCancelEdit").onclick = resetProductForm;

$("#productForm").addEventListener("submit", e => {
  e.preventDefault();
  const f = Object.fromEntries(new FormData(e.target));
  const data = {
    tipo: f.tipo, nombre: f.nombre.trim(), marca: (f.marca || "").trim(),
    ml: +f.ml || 0, precio: +f.precio || 0,
    descuento: Math.min(100, Math.max(0, +f.descuento || 0)),
    descripcion: (f.descripcion || "").trim()
  };
  if (editingId) {
    const p = products.find(x => x.id === editingId);
    Object.assign(p, data); if (pendingImage) p.imagen = pendingImage;
  } else {
    products.unshift({ id: uid(), ...data, imagen: pendingImage });
  }
  if (!save("hotpst_products", products)) { products = load("hotpst_products", []); return; }
  const wasEditing = !!editingId;
  resetProductForm();
  renderGrid(); renderCart(); renderAdmin();
  toast(wasEditing ? "Cambios guardados" : "Producto guardado");
});

function deleteProduct(id) {
  if (!confirm("¿Eliminar este producto?")) return;
  products = products.filter(p => p.id !== id);
  cart = cart.filter(c => c.id !== id); favs = favs.filter(f => f !== id);
  save("hotpst_products", products); save("hotpst_favs", favs);
  if (editingId === id) resetProductForm();
  renderGrid(); renderCart(); renderAdmin();
}
function deleteOrder(id) {
  if (!confirm("¿Eliminar esta compra?")) return;
  orders = orders.filter(o => o.id !== id);
  save("hotpst_orders", orders); renderAdmin();
}

function renderAdmin() {
  $("#adminProducts").innerHTML = products.length ? products.map(p => `
    <div class="arow">
      <div class="ci-img">${p.imagen ? `<img src="${p.imagen}" alt="">` : placeholder(p)}</div>
      <div><b>${esc(p.nombre)}</b><br><small>${p.tipo} · ${money(p.precio)}${p.descuento ? ` · -${p.descuento}%` : ""}</small></div>
      <div class="acts"><button class="ed" data-edit="${p.id}">Editar</button><button class="rm" data-delp="${p.id}">Eliminar</button></div>
    </div>`).join("") : '<p class="empty-cart">Sin productos.</p>';
  $("#adminOrders").innerHTML = orders.length ? orders.map(o => orderCard(o, true)).join("") : '<p class="empty-cart">Aún no hay compras registradas.</p>';
  const sf = $("#settingsForm");
  sf.whatsapp.value = settings.whatsapp || "";
  sf.adOn.checked = !!settings.ad.on; sf.adTag.value = settings.ad.tag || "";
  sf.adTitle.value = settings.ad.title || ""; sf.adText.value = settings.ad.text || "";
  sf.adQuery.value = settings.ad.query || "";
}

$("#settingsForm").addEventListener("submit", e => {
  e.preventDefault();
  const f = e.target;
  settings.whatsapp = f.whatsapp.value.replace(/\D/g, "");
  settings.ad = {
    on: f.adOn.checked,
    tag: f.adTag.value.trim(), title: f.adTitle.value.trim() || AD_DEFAULT.title,
    text: f.adText.value.trim(), query: f.adQuery.value.trim()
  };
  save("hotpst_settings", settings); updateWa(); renderAd(); toast("Ajustes guardados");
});
$("#btnExport").onclick = () => {
  const blob = new Blob([JSON.stringify(orders, null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = "compras-hotpst.json"; a.click();
  URL.revokeObjectURL(a.href);
};
function updateWa() {
  const w = $("#waLine");
  if (settings.whatsapp) { w.hidden = false; w.innerHTML = `¿Dudas? <a href="https://wa.me/${settings.whatsapp}" target="_blank" rel="noopener">Escríbenos por WhatsApp</a>`; }
  else w.hidden = true;
}

/* Anuncio de portada (editable en Admin → Ajustes) */
function renderAd() {
  const a = settings.ad, sec = $("#promo");
  sec.hidden = !a.on;
  $("#promoTag").textContent = a.tag;
  $("#promoTitle").textContent = a.title;
  $("#promoText").textContent = a.text;
  $("#promoBtn").hidden = !a.query;
}
$("#promoBtn").onclick = () => {
  query = settings.ad.query || ""; filter = "todos";
  $("#search").value = query;
  $$(".chip").forEach(c => c.classList.toggle("active", c.dataset.filter === "todos"));
  movePill(); renderGrid();
  $("#catalogo").scrollIntoView({ behavior: "smooth" });
  if (!visibleProducts().length) toast(`Aún no hay productos "${query}". Agrégalos desde Admin.`);
};

/* =========================================================
   EFECTOS: nav, progreso, reveal, contadores, rotador
   ========================================================= */
const nav = $("#nav"), progress = $("#progress");
let lastY = 0, ticking = false;
addEventListener("scroll", () => {
  if (ticking) return; ticking = true;
  requestAnimationFrame(() => {
    const y = scrollY, max = document.documentElement.scrollHeight - innerHeight;
    progress.style.transform = `scaleX(${max > 0 ? y / max : 0})`;
    nav.classList.toggle("scrolled", y > 30);
    nav.classList.toggle("hide", y > lastY && y > 260 && !$("#menu").classList.contains("open"));
    lastY = y; ticking = false;
  });
}, { passive: true });

$("#burger").onclick = () => { $("#menu").classList.toggle("open"); $("#burger").classList.toggle("open"); nav.classList.remove("hide"); };
$$("#menu a").forEach(a => a.addEventListener("click", () => { $("#menu").classList.remove("open"); $("#burger").classList.remove("open"); }));

const io = new IntersectionObserver(es => es.forEach(en => {
  if (!en.isIntersecting) return;
  en.target.classList.add("in");
  if (en.target.classList.contains("stat")) countUp($("b", en.target));
  io.unobserve(en.target);
}), { threshold: .15 });
$$(".reveal").forEach(el => io.observe(el));

function statValue(key) {
  return key === "total" ? products.length
    : key === "off" ? products.filter(p => p.descuento > 0).length
    : products.filter(p => p.tipo === key).length;
}
function countUp(el) {
  const target = statValue(el.dataset.count), t0 = performance.now(), dur = 1300;
  el._counted = true;
  (function step(t) {
    const k = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - k, 3);
    el.textContent = Math.round(target * e);
    if (k < 1) requestAnimationFrame(step);
  })(t0);
}
function updateStats() {
  $$(".stat b").forEach(b => { if (b._counted) b.textContent = statValue(b.dataset.count); });
}

/* Frase rotativa del hero */
(function rotator() {
  const el = $("#rotator"); let i = 0;
  setInterval(() => {
    el.classList.add("swap");
    setTimeout(() => { i = (i + 1) % CONFIG.ROTATOR.length; el.textContent = CONFIG.ROTATOR[i]; el.classList.remove("swap"); }, 380);
  }, 2800);
})();

$("#year").textContent = new Date().getFullYear();

/* =========================================================
   INICIO
   ========================================================= */
renderGrid();
renderCart();
renderAdmin();
updateWa();
renderAd();
updateAccountUI();
(document.fonts?.ready || Promise.resolve()).then(() => movePill(true));

// Si ya hay sesión o ya entró en esta visita, no se muestra la bienvenida.
if (currentUser() || sessionStorage.getItem("hotpst_entered")) {
  welcome.classList.add("gone");
  document.body.classList.remove("locked");
}
